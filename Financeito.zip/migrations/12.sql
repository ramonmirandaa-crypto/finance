
CREATE TABLE webhook_logs (
id INTEGER PRIMARY KEY AUTOINCREMENT,
webhook_id TEXT NOT NULL,
success BOOLEAN NOT NULL DEFAULT FALSE,
error_message TEXT,
attempt_at DATETIME NOT NULL,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_webhook_logs_webhook_id ON webhook_logs(webhook_id);
CREATE INDEX idx_webhook_logs_attempt_at ON webhook_logs(attempt_at);

CREATE TABLE webhook_configs (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
webhook_url TEXT NOT NULL,
events TEXT NOT NULL, -- JSON array
is_active BOOLEAN DEFAULT TRUE,
max_retries INTEGER DEFAULT 3,
retry_delay_seconds INTEGER DEFAULT 60,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
UNIQUE(user_id)
);
