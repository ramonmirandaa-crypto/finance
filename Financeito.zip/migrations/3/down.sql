
DROP INDEX idx_loans_user_id;
DROP TABLE loans;
DROP INDEX idx_investments_user_id;
DROP TABLE investments;
DROP INDEX idx_credit_cards_user_id;
DROP TABLE credit_cards;
