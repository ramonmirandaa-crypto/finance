-- Drop the indexes created in migration #11
DROP INDEX IF EXISTS idx_user_configs_key;
DROP INDEX IF EXISTS idx_loans_user;
DROP INDEX IF EXISTS idx_investments_user;
DROP INDEX IF EXISTS idx_credit_cards_user;
DROP INDEX IF EXISTS idx_pluggy_connections_user_item;
DROP INDEX IF EXISTS idx_expenses_hash;
DROP INDEX IF EXISTS idx_expenses_pluggy;
DROP INDEX IF EXISTS idx_expenses_user_date;
DROP INDEX IF EXISTS idx_transactions_date_desc;
DROP INDEX IF EXISTS idx_transactions_hash;
DROP INDEX IF EXISTS idx_transactions_pluggy;
DROP INDEX IF EXISTS idx_transactions_user_account;
DROP INDEX IF EXISTS idx_accounts_sync;
DROP INDEX IF EXISTS idx_accounts_type_status;
DROP INDEX IF EXISTS idx_accounts_user_pluggy;