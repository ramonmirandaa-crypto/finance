
DROP INDEX idx_expenses_pluggy_transaction_id;
ALTER TABLE expenses DROP COLUMN is_synced_from_bank;
ALTER TABLE expenses DROP COLUMN pluggy_account_id;
ALTER TABLE expenses DROP COLUMN pluggy_transaction_id;
DROP INDEX idx_pluggy_connections_item_id;
DROP INDEX idx_pluggy_connections_user_id;
DROP TABLE pluggy_connections;
