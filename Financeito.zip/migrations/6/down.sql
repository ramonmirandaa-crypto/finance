
DROP INDEX idx_user_configs_user_key;
DROP TABLE user_configs;
