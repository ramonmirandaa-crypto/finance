
-- Add Pluggy-specific columns to loans table
ALTER TABLE loans ADD COLUMN pluggy_loan_id TEXT;
ALTER TABLE loans ADD COLUMN pluggy_account_id TEXT;
ALTER TABLE loans ADD COLUMN contract_number TEXT;
ALTER TABLE loans ADD COLUMN loan_type TEXT;
ALTER TABLE loans ADD COLUMN status TEXT DEFAULT 'ACTIVE';
ALTER TABLE loans ADD COLUMN total_installments INTEGER;
ALTER TABLE loans ADD COLUMN remaining_installments INTEGER;
ALTER TABLE loans ADD COLUMN installment_frequency TEXT;
ALTER TABLE loans ADD COLUMN next_due_date DATE;
ALTER TABLE loans ADD COLUMN is_synced_from_bank BOOLEAN DEFAULT FALSE;
ALTER TABLE loans ADD COLUMN guarantee_type TEXT;
ALTER TABLE loans ADD COLUMN cet_rate REAL;
