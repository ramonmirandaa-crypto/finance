
-- Add new columns to transactions table for enhanced features
ALTER TABLE transactions ADD COLUMN tags TEXT; -- JSON array of tags
ALTER TABLE transactions ADD COLUMN notes TEXT; -- User notes
ALTER TABLE transactions ADD COLUMN reconciled BOOLEAN DEFAULT FALSE; -- Reconciliation status
ALTER TABLE transactions ADD COLUMN payment_method TEXT; -- PIX, TED, DOC, etc.
ALTER TABLE transactions ADD COLUMN merchant_category TEXT; -- MCC or merchant category
ALTER TABLE transactions ADD COLUMN location_data TEXT; -- JSON location info
ALTER TABLE transactions ADD COLUMN foreign_exchange_data TEXT; -- JSON FX info
ALTER TABLE transactions ADD COLUMN fees_data TEXT; -- JSON fees info
ALTER TABLE transactions ADD COLUMN pix_data TEXT; -- JSON PIX specific data
ALTER TABLE transactions ADD COLUMN installment_data TEXT; -- JSON installment info
ALTER TABLE transactions ADD COLUMN status TEXT DEFAULT 'completed'; -- pending, completed, failed
ALTER TABLE transactions ADD COLUMN processed_at DATETIME;
ALTER TABLE transactions ADD COLUMN provider_code TEXT; -- Provider's transaction code
ALTER TABLE transactions ADD COLUMN operation_type TEXT; -- TED, DOC, PIX, etc.

-- Create transaction categories table
CREATE TABLE transaction_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  color TEXT,
  parent_id INTEGER,
  description TEXT,
  keywords TEXT, -- JSON array
  rules TEXT, -- JSON array of rules
  is_default BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES transaction_categories(id),
  UNIQUE(user_id, name)
);

-- Create enhanced indexes for better performance (skip if exists)
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category);
CREATE INDEX IF NOT EXISTS idx_transactions_merchant ON transactions(merchant_name);
CREATE INDEX IF NOT EXISTS idx_transactions_amount ON transactions(amount);
CREATE INDEX IF NOT EXISTS idx_transactions_reconciled ON transactions(reconciled);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_transactions_payment_method ON transactions(payment_method);

-- Insert default categories for all existing users
INSERT OR IGNORE INTO transaction_categories (user_id, name, color, description, is_default)
SELECT DISTINCT user_id, 'Alimentação', '#FF6B6B', 'Gastos com comida e bebida', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Transporte', '#4ECDC4', 'Gastos com locomoção', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Compras', '#45B7D1', 'Compras em geral', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Entretenimento', '#96CEB4', 'Lazer e entretenimento', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Contas e Serviços', '#FFEAA7', 'Contas e serviços', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Saúde', '#DDA0DD', 'Gastos com saúde', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Viagem', '#98D8C8', 'Gastos com viagem', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Educação', '#A29BFE', 'Gastos com educação', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Cuidados Pessoais', '#FD79A8', 'Cuidados pessoais', TRUE FROM transactions
UNION
SELECT DISTINCT user_id, 'Outros', '#B2B2B2', 'Outros gastos', TRUE FROM transactions;
