
-- Remove Pluggy-specific columns from loans table
ALTER TABLE loans DROP COLUMN cet_rate;
ALTER TABLE loans DROP COLUMN guarantee_type;
ALTER TABLE loans DROP COLUMN is_synced_from_bank;
ALTER TABLE loans DROP COLUMN next_due_date;
ALTER TABLE loans DROP COLUMN installment_frequency;
ALTER TABLE loans DROP COLUMN remaining_installments;
ALTER TABLE loans DROP COLUMN total_installments;
ALTER TABLE loans DROP COLUMN status;
ALTER TABLE loans DROP COLUMN loan_type;
ALTER TABLE loans DROP COLUMN contract_number;
ALTER TABLE loans DROP COLUMN pluggy_account_id;
ALTER TABLE loans DROP COLUMN pluggy_loan_id;
