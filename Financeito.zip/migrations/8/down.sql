
-- Remove investment specific fields
ALTER TABLE accounts DROP COLUMN unit_price;
ALTER TABLE accounts DROP COLUMN quantity;
ALTER TABLE accounts DROP COLUMN isin;
ALTER TABLE accounts DROP COLUMN investment_maturity_date;
ALTER TABLE accounts DROP COLUMN indexer;
ALTER TABLE accounts DROP COLUMN rate_type;
ALTER TABLE accounts DROP COLUMN investment_rate;
ALTER TABLE accounts DROP COLUMN last_movement_date;
ALTER TABLE accounts DROP COLUMN gross_worth;
ALTER TABLE accounts DROP COLUMN net_worth;
ALTER TABLE accounts DROP COLUMN portfolio_value;
ALTER TABLE accounts DROP COLUMN investment_type;
ALTER TABLE accounts DROP COLUMN product_name;

-- Remove loan specific fields
ALTER TABLE accounts DROP COLUMN origination_date;
ALTER TABLE accounts DROP COLUMN maturity_date;
ALTER TABLE accounts DROP COLUMN due_date;
ALTER TABLE accounts DROP COLUMN total_installments;
ALTER TABLE accounts DROP COLUMN remaining_installments;
ALTER TABLE accounts DROP COLUMN installment_frequency;
ALTER TABLE accounts DROP COLUMN installment_amount;
ALTER TABLE accounts DROP COLUMN loan_interest_rate;
ALTER TABLE accounts DROP COLUMN outstanding_balance;
ALTER TABLE accounts DROP COLUMN principal_amount;
ALTER TABLE accounts DROP COLUMN contract_number;

-- Remove credit card specific fields
ALTER TABLE accounts DROP COLUMN card_type;
ALTER TABLE accounts DROP COLUMN card_network;
ALTER TABLE accounts DROP COLUMN annual_fee;
ALTER TABLE accounts DROP COLUMN fine_rate;
ALTER TABLE accounts DROP COLUMN interest_rate;
ALTER TABLE accounts DROP COLUMN total_installment_balance;
ALTER TABLE accounts DROP COLUMN is_limit_flexible;
ALTER TABLE accounts DROP COLUMN available_credit_limit;
ALTER TABLE accounts DROP COLUMN credit_limit;
ALTER TABLE accounts DROP COLUMN minimum_payment;
ALTER TABLE accounts DROP COLUMN balance_due_date;
ALTER TABLE accounts DROP COLUMN balance_close_date;
ALTER TABLE accounts DROP COLUMN credit_brand;
ALTER TABLE accounts DROP COLUMN credit_level;

-- Remove bank account specific fields
ALTER TABLE accounts DROP COLUMN compe_code;
ALTER TABLE accounts DROP COLUMN account_digit;
ALTER TABLE accounts DROP COLUMN branch_code;
ALTER TABLE accounts DROP COLUMN unarranged_overdraft_amount;
ALTER TABLE accounts DROP COLUMN overdraft_used_limit;
ALTER TABLE accounts DROP COLUMN overdraft_contracted_limit;
ALTER TABLE accounts DROP COLUMN automatically_invested_balance;
ALTER TABLE accounts DROP COLUMN closing_balance;
ALTER TABLE accounts DROP COLUMN transfer_number;

-- Remove general Pluggy fields
ALTER TABLE accounts DROP COLUMN pluggy_last_updated_at;
ALTER TABLE accounts DROP COLUMN pluggy_updated_at;
ALTER TABLE accounts DROP COLUMN pluggy_created_at;
ALTER TABLE accounts DROP COLUMN sub_category;
ALTER TABLE accounts DROP COLUMN category;
ALTER TABLE accounts DROP COLUMN status;
ALTER TABLE accounts DROP COLUMN tax_number;
ALTER TABLE accounts DROP COLUMN owner;
ALTER TABLE accounts DROP COLUMN number;
ALTER TABLE accounts DROP COLUMN marketing_name;
