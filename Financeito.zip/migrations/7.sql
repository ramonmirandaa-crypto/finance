
-- Create accounts table to represent different types of financial accounts
CREATE TABLE accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  pluggy_account_id TEXT,
  pluggy_item_id TEXT,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL, -- 'checking', 'savings', 'credit_card', 'loan', 'investment'
  account_subtype TEXT,
  institution_name TEXT,
  balance REAL DEFAULT 0,
  currency_code TEXT DEFAULT 'BRL',
  is_active BOOLEAN DEFAULT TRUE,
  sync_enabled BOOLEAN DEFAULT TRUE,
  last_sync_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for better performance
CREATE INDEX idx_accounts_user_id ON accounts(user_id);
CREATE INDEX idx_accounts_pluggy_account_id ON accounts(pluggy_account_id);
CREATE INDEX idx_accounts_type ON accounts(account_type);

-- Create transactions table to replace/complement expenses
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  account_id INTEGER,
  pluggy_transaction_id TEXT,
  transaction_hash TEXT,
  amount REAL NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  transaction_type TEXT NOT NULL, -- 'income', 'expense', 'transfer'
  date DATE NOT NULL,
  balance_after REAL,
  merchant_name TEXT,
  is_synced_from_bank BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES accounts(id)
);

-- Add indexes for transactions
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_account_id ON transactions(account_id);
CREATE INDEX idx_transactions_date ON transactions(date);
CREATE INDEX idx_transactions_pluggy_id ON transactions(pluggy_transaction_id);
CREATE INDEX idx_transactions_hash ON transactions(transaction_hash);

-- Migrate existing expenses to transactions
INSERT INTO transactions (
  user_id, amount, description, category, transaction_type, date, 
  pluggy_transaction_id, transaction_hash, is_synced_from_bank, created_at, updated_at
)
SELECT 
  user_id, 
  ABS(amount) as amount,
  description, 
  category, 
  'expense' as transaction_type,
  date,
  pluggy_transaction_id,
  transaction_hash,
  COALESCE(is_synced_from_bank, FALSE),
  created_at,
  updated_at
FROM expenses;
