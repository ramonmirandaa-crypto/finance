
-- Remove indexes
DROP INDEX IF EXISTS idx_transactions_user_date;
DROP INDEX IF EXISTS idx_transactions_category;
DROP INDEX IF EXISTS idx_transactions_merchant;
DROP INDEX IF EXISTS idx_transactions_amount;
DROP INDEX IF EXISTS idx_transactions_reconciled;
DROP INDEX IF EXISTS idx_transactions_status;
DROP INDEX IF EXISTS idx_transactions_type;
DROP INDEX IF EXISTS idx_transactions_payment_method;

-- Drop transaction categories table
DROP TABLE IF EXISTS transaction_categories;

-- Remove new columns from transactions table
ALTER TABLE transactions DROP COLUMN operation_type;
ALTER TABLE transactions DROP COLUMN provider_code;
ALTER TABLE transactions DROP COLUMN processed_at;
ALTER TABLE transactions DROP COLUMN status;
ALTER TABLE transactions DROP COLUMN installment_data;
ALTER TABLE transactions DROP COLUMN pix_data;
ALTER TABLE transactions DROP COLUMN fees_data;
ALTER TABLE transactions DROP COLUMN foreign_exchange_data;
ALTER TABLE transactions DROP COLUMN location_data;
ALTER TABLE transactions DROP COLUMN merchant_category;
ALTER TABLE transactions DROP COLUMN payment_method;
ALTER TABLE transactions DROP COLUMN reconciled;
ALTER TABLE transactions DROP COLUMN notes;
ALTER TABLE transactions DROP COLUMN tags;
