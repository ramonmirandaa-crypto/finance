
ALTER TABLE expenses ADD COLUMN transaction_hash TEXT;
CREATE INDEX IF NOT EXISTS idx_expenses_transaction_hash ON expenses(transaction_hash);
