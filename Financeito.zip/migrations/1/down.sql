
DROP TABLE expenses;
