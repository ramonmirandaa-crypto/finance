
-- Add column to link credit_cards with pluggy accounts
ALTER TABLE credit_cards ADD COLUMN linked_account_id INTEGER;

-- Add foreign key reference (note: SQLite doesn't enforce this but it's good for documentation)
-- FOREIGN KEY (linked_account_id) REFERENCES accounts(id)
