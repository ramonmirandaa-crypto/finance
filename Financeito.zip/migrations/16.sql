
-- Add indexes to optimize queries and reduce compound SELECT complexity
-- This should resolve the "too many terms in compound SELECT" error

CREATE INDEX IF NOT EXISTS idx_accounts_user_pluggy ON accounts(user_id, pluggy_account_id);
CREATE INDEX IF NOT EXISTS idx_accounts_item ON accounts(pluggy_item_id);
CREATE INDEX IF NOT EXISTS idx_accounts_type_status ON accounts(account_type, status);
CREATE INDEX IF NOT EXISTS idx_accounts_sync ON accounts(sync_enabled, last_sync_at);

CREATE INDEX IF NOT EXISTS idx_transactions_user_account ON transactions(user_id, account_id);
CREATE INDEX IF NOT EXISTS idx_transactions_pluggy ON transactions(pluggy_transaction_id);
CREATE INDEX IF NOT EXISTS idx_transactions_hash ON transactions(transaction_hash);
CREATE INDEX IF NOT EXISTS idx_transactions_date_desc ON transactions(date DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_type_category ON transactions(transaction_type, category);

CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_pluggy ON expenses(pluggy_transaction_id);
CREATE INDEX IF NOT EXISTS idx_expenses_hash ON expenses(transaction_hash);

CREATE INDEX IF NOT EXISTS idx_pluggy_connections_user_item ON pluggy_connections(user_id, pluggy_item_id);
CREATE INDEX IF NOT EXISTS idx_pluggy_connections_status ON pluggy_connections(connection_status);

CREATE INDEX IF NOT EXISTS idx_credit_cards_user ON credit_cards(user_id);
CREATE INDEX IF NOT EXISTS idx_credit_cards_linked ON credit_cards(linked_account_id);

CREATE INDEX IF NOT EXISTS idx_investments_user ON investments(user_id);
CREATE INDEX IF NOT EXISTS idx_loans_user ON loans(user_id);

CREATE INDEX IF NOT EXISTS idx_user_configs_user_key ON user_configs(user_id, config_key);
