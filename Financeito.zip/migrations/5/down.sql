
DROP INDEX IF EXISTS idx_expenses_transaction_hash;
ALTER TABLE expenses DROP COLUMN transaction_hash;
