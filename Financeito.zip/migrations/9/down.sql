
DROP INDEX IF EXISTS idx_credit_card_transactions_date;
DROP INDEX IF EXISTS idx_credit_card_transactions_account_id;
DROP INDEX IF EXISTS idx_credit_card_transactions_bill_id;
DROP INDEX IF EXISTS idx_credit_card_bills_due_date;
DROP INDEX IF EXISTS idx_credit_card_bills_account_id;
DROP INDEX IF EXISTS idx_credit_card_bills_user_id;
DROP TABLE IF EXISTS credit_card_transactions;
DROP TABLE IF EXISTS credit_card_bills;
