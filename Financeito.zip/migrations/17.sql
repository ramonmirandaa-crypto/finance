-- Migration #11: Fix compound SELECT issue by optimizing table structure
-- This migration breaks down complex operations to avoid SQLite limits

-- Create optimized indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_accounts_user_pluggy ON accounts(user_id, pluggy_account_id);
CREATE INDEX IF NOT EXISTS idx_accounts_type_status ON accounts(account_type, status);
CREATE INDEX IF NOT EXISTS idx_accounts_sync ON accounts(sync_enabled, last_sync_at);

CREATE INDEX IF NOT EXISTS idx_transactions_user_account ON transactions(user_id, account_id);
CREATE INDEX IF NOT EXISTS idx_transactions_pluggy ON transactions(pluggy_transaction_id);
CREATE INDEX IF NOT EXISTS idx_transactions_hash ON transactions(transaction_hash);
CREATE INDEX IF NOT EXISTS idx_transactions_date_desc ON transactions(date DESC, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_pluggy ON expenses(pluggy_transaction_id);
CREATE INDEX IF NOT EXISTS idx_expenses_hash ON expenses(transaction_hash);

CREATE INDEX IF NOT EXISTS idx_pluggy_connections_user_item ON pluggy_connections(user_id, pluggy_item_id);
CREATE INDEX IF NOT EXISTS idx_credit_cards_user ON credit_cards(user_id, linked_account_id);
CREATE INDEX IF NOT EXISTS idx_investments_user ON investments(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_loans_user ON loans(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_configs_key ON user_configs(user_id, config_key);