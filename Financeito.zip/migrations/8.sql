
-- Add comprehensive Pluggy account fields to accounts table
ALTER TABLE accounts ADD COLUMN marketing_name TEXT;
ALTER TABLE accounts ADD COLUMN number TEXT;
ALTER TABLE accounts ADD COLUMN owner TEXT;
ALTER TABLE accounts ADD COLUMN tax_number TEXT;
ALTER TABLE accounts ADD COLUMN status TEXT;
ALTER TABLE accounts ADD COLUMN category TEXT;
ALTER TABLE accounts ADD COLUMN sub_category TEXT;
ALTER TABLE accounts ADD COLUMN pluggy_created_at TEXT;
ALTER TABLE accounts ADD COLUMN pluggy_updated_at TEXT;
ALTER TABLE accounts ADD COLUMN pluggy_last_updated_at TEXT;

-- Bank account specific fields
ALTER TABLE accounts ADD COLUMN transfer_number TEXT;
ALTER TABLE accounts ADD COLUMN closing_balance REAL;
ALTER TABLE accounts ADD COLUMN automatically_invested_balance REAL;
ALTER TABLE accounts ADD COLUMN overdraft_contracted_limit REAL;
ALTER TABLE accounts ADD COLUMN overdraft_used_limit REAL;
ALTER TABLE accounts ADD COLUMN unarranged_overdraft_amount REAL;
ALTER TABLE accounts ADD COLUMN branch_code TEXT;
ALTER TABLE accounts ADD COLUMN account_digit TEXT;
ALTER TABLE accounts ADD COLUMN compe_code TEXT;

-- Credit card specific fields
ALTER TABLE accounts ADD COLUMN credit_level TEXT;
ALTER TABLE accounts ADD COLUMN credit_brand TEXT;
ALTER TABLE accounts ADD COLUMN balance_close_date TEXT;
ALTER TABLE accounts ADD COLUMN balance_due_date TEXT;
ALTER TABLE accounts ADD COLUMN minimum_payment REAL;
ALTER TABLE accounts ADD COLUMN credit_limit REAL;
ALTER TABLE accounts ADD COLUMN available_credit_limit REAL;
ALTER TABLE accounts ADD COLUMN is_limit_flexible BOOLEAN;
ALTER TABLE accounts ADD COLUMN total_installment_balance REAL;
ALTER TABLE accounts ADD COLUMN interest_rate REAL;
ALTER TABLE accounts ADD COLUMN fine_rate REAL;
ALTER TABLE accounts ADD COLUMN annual_fee REAL;
ALTER TABLE accounts ADD COLUMN card_network TEXT;
ALTER TABLE accounts ADD COLUMN card_type TEXT;

-- Loan specific fields
ALTER TABLE accounts ADD COLUMN contract_number TEXT;
ALTER TABLE accounts ADD COLUMN principal_amount REAL;
ALTER TABLE accounts ADD COLUMN outstanding_balance REAL;
ALTER TABLE accounts ADD COLUMN loan_interest_rate REAL;
ALTER TABLE accounts ADD COLUMN installment_amount REAL;
ALTER TABLE accounts ADD COLUMN installment_frequency TEXT;
ALTER TABLE accounts ADD COLUMN remaining_installments INTEGER;
ALTER TABLE accounts ADD COLUMN total_installments INTEGER;
ALTER TABLE accounts ADD COLUMN due_date TEXT;
ALTER TABLE accounts ADD COLUMN maturity_date TEXT;
ALTER TABLE accounts ADD COLUMN origination_date TEXT;

-- Investment specific fields
ALTER TABLE accounts ADD COLUMN product_name TEXT;
ALTER TABLE accounts ADD COLUMN investment_type TEXT;
ALTER TABLE accounts ADD COLUMN portfolio_value REAL;
ALTER TABLE accounts ADD COLUMN net_worth REAL;
ALTER TABLE accounts ADD COLUMN gross_worth REAL;
ALTER TABLE accounts ADD COLUMN last_movement_date TEXT;
ALTER TABLE accounts ADD COLUMN investment_rate REAL;
ALTER TABLE accounts ADD COLUMN rate_type TEXT;
ALTER TABLE accounts ADD COLUMN indexer TEXT;
ALTER TABLE accounts ADD COLUMN investment_maturity_date TEXT;
ALTER TABLE accounts ADD COLUMN isin TEXT;
ALTER TABLE accounts ADD COLUMN quantity REAL;
ALTER TABLE accounts ADD COLUMN unit_price REAL;
