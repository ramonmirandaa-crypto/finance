
CREATE TABLE pluggy_connections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  pluggy_item_id TEXT NOT NULL,
  institution_name TEXT,
  connection_status TEXT DEFAULT 'CONNECTED',
  last_sync_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pluggy_connections_user_id ON pluggy_connections(user_id);
CREATE INDEX idx_pluggy_connections_item_id ON pluggy_connections(pluggy_item_id);

ALTER TABLE expenses ADD COLUMN pluggy_transaction_id TEXT;
ALTER TABLE expenses ADD COLUMN pluggy_account_id TEXT;
ALTER TABLE expenses ADD COLUMN is_synced_from_bank BOOLEAN DEFAULT FALSE;

CREATE INDEX idx_expenses_pluggy_transaction_id ON expenses(pluggy_transaction_id);
