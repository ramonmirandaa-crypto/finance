
ALTER TABLE expenses DROP COLUMN user_id;
