
ALTER TABLE expenses ADD COLUMN user_id TEXT;
