
DROP INDEX idx_webhook_logs_attempt_at;
DROP INDEX idx_webhook_logs_webhook_id;
DROP TABLE webhook_logs;
DROP TABLE webhook_configs;
