
-- Create credit card bills table
CREATE TABLE credit_card_bills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  account_id INTEGER,
  pluggy_bill_id TEXT,
  
  -- Basic bill information
  closing_date DATE,
  due_date DATE,
  total_amount REAL DEFAULT 0,
  minimum_payment REAL DEFAULT 0,
  previous_bill_balance REAL DEFAULT 0,
  
  -- Payment information
  paid_amount REAL DEFAULT 0,
  payment_date DATE,
  is_fully_paid BOOLEAN DEFAULT FALSE,
  
  -- Interest and fees
  interest_rate REAL,
  late_fee REAL DEFAULT 0,
  annual_fee REAL DEFAULT 0,
  international_fee REAL DEFAULT 0,
  
  -- Bill status and metadata
  bill_status TEXT,
  currency_code TEXT DEFAULT 'BRL',
  bill_month INTEGER,
  bill_year INTEGER,
  
  -- Pluggy metadata
  pluggy_created_at TEXT,
  pluggy_updated_at TEXT,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (account_id) REFERENCES accounts(id)
);

-- Create credit card transactions table (for bill details)
CREATE TABLE credit_card_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  bill_id INTEGER,
  account_id INTEGER,
  pluggy_transaction_id TEXT,
  
  -- Transaction details
  amount REAL NOT NULL,
  description TEXT,
  category TEXT,
  date DATE,
  
  -- Credit card specific fields
  installment_number INTEGER,
  total_installments INTEGER,
  merchant_name TEXT,
  merchant_category TEXT,
  
  -- Transaction metadata
  transaction_type TEXT, -- 'purchase', 'payment', 'fee', 'interest', 'adjustment'
  currency_code TEXT DEFAULT 'BRL',
  
  -- Pluggy metadata
  pluggy_created_at TEXT,
  pluggy_updated_at TEXT,
  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (bill_id) REFERENCES credit_card_bills(id),
  FOREIGN KEY (account_id) REFERENCES accounts(id)
);

-- Create indexes for better performance
CREATE INDEX idx_credit_card_bills_user_id ON credit_card_bills(user_id);
CREATE INDEX idx_credit_card_bills_account_id ON credit_card_bills(account_id);
CREATE INDEX idx_credit_card_bills_due_date ON credit_card_bills(due_date);
CREATE INDEX idx_credit_card_transactions_bill_id ON credit_card_transactions(bill_id);
CREATE INDEX idx_credit_card_transactions_account_id ON credit_card_transactions(account_id);
CREATE INDEX idx_credit_card_transactions_date ON credit_card_transactions(date);
