
-- Remove the linked account column
ALTER TABLE credit_cards DROP COLUMN linked_account_id;
